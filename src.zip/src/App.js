// import logo from './logo.svg';
import './App.css';
import Quiz from './quiz';

function App() {
  return(
    <>
    <Quiz/>
    </>
  );
}

export default App;
